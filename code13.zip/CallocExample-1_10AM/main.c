#include <stdio.h>
#include <stdlib.h>
int main()
{
   int size;
   char *text = NULL;

   printf("Enter limit of the text: \n");
   scanf("%d", &size);

   //Allocating Memory
   text = (char *) calloc(size, sizeof(char)); //Memory Allocation

   if (text != NULL)
   {
        printf("Enter some text: \n");
           scanf(" ");
           gets(text);
        printf("Inputted text is: %s\n", text);
   }
   //Deallocating Memory
       free(text);
       text = NULL;
       return 0;
}
