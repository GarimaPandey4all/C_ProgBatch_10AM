#include <stdio.h>
#include <stdlib.h>

int main()
{
    enum Week {Monday=2, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday};

    enum Week Today;

    Today = Thursday;

    printf("Today is: %d", Today);

    return 0;
}
