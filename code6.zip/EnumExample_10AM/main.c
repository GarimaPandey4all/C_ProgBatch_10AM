#include <stdio.h>
#include <stdlib.h>

int main()
{
    enum Gender{Male=1, Female};

    enum Gender othergender;

    othergender = Male;

    enum Gender anothergender;

    anothergender = Female;

    printf("Male is: %d\n", othergender);

    printf("Female is: %d", anothergender);

    return 0;
}
