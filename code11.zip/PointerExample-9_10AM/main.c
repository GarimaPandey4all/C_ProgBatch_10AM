#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 99; int number = 200;

    const int *pvalue = NULL; //pointer to a constant

    pvalue = &value;

    *pvalue = 100; //error

    pvalue = &number; //Okay

    printf("Value of value:%d", *pvalue);

    return 0;
}
