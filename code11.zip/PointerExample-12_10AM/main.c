#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i = 10;
    float j = 2.34;
    char z = 'A';

    void *vptr; //void pointer

    vptr = &i;
    printf("Value of i:%d\n", *(int *)vptr); //void pointer to int pointer

    vptr = &j;
    printf("Value of j:%.2f\n", *(float *)vptr); //void pointer to float pointer

    vptr = &z;
    printf("Value of Z:%c", *(char *)vptr); //void pointer to char pointer

    return 0;
}
