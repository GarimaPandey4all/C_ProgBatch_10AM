#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int value = 99; //constant variable

    const int number = 101;

    const int *const pvalue = &value;

    //*pvalue = 100; //error

    //pvalue = &number; //error

    //value = 100; //error

    printf("Value of value:%d", *pvalue);

    return 0;
}
