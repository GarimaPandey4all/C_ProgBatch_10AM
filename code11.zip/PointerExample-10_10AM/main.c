#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 99;

    int number = 200;

    int *const pvalue = &value; //constant pointer

    //pvalue = &value; //re-initialize //error

    *pvalue = 100; //Okay

    //pvalue = &number; //error

    printf("Value is:%d", *pvalue);

    return 0;
}
