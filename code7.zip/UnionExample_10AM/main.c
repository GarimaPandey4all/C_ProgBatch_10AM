#include <stdio.h>
#include <stdlib.h>

union Data
{
    int i;
    int a;
    char c;
}data;

//union Data data;

int main()
{
    data.i= 10;
    data.c = 'C';
    data.a= 100;

    printf("I is: %d\n", data.i);
    printf("C is: %c\n", data.c);
    printf("A is: %d", data.a);

    return 0;
}
