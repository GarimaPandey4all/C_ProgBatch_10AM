#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[20];

    printf("Enter your Name:");
    //scanf("%s", &str1);
    gets(str1);

    //puts(str1);
    printf("Your Name is: %s", str1);

    return 0;
}
