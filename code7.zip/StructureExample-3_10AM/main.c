#include <stdio.h>
#include <stdlib.h>

struct Employee
{
    int id;
    int dept;
    int salary;
    int contact;
    char name;
};

struct Employee Emp1;


int main()
{
    Emp1.contact= 859897897;
    Emp1.dept = 03;
    Emp1.id = 101;
    Emp1.salary = 25000;
    Emp1.name = 'R';

    printf("Employee Details:\n");
    printf("Employee's ID is:%d\n", Emp1.id);
    printf("Employee's Name is:%c\n", Emp1.name);
    printf("Employee's Department is:%d\n", Emp1.dept);
    printf("Employee's Salary is:%d\n", Emp1.salary);
    printf("Employee's Contact is:%d\n", Emp1.contact);

    return 0;
}
