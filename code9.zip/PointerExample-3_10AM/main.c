#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 15;

    int *pnumber = NULL;

    int result=0;

    pnumber = &number;

    result = *pnumber + 10;

    printf("Result is: %d", result);

    return 0;
}
