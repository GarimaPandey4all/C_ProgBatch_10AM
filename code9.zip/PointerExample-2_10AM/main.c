#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 99;

    int *pnumber = NULL;

    pnumber = &number;

    printf("Address of number:%d\n", pnumber); //value of pnumber

    printf("Address of number:%p\n", pnumber); //hexadecimal format

    printf("Value of number:%d", *pnumber);

    return 0;
}
