#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 99; int value = 20;

    int *pnumber = &number;

    *pnumber = 100;

    printf("Number is:%d\n", number);

    pnumber = &value;

    *pnumber = 50;

    printf("Value is:%d", value);

    return 0;
}
