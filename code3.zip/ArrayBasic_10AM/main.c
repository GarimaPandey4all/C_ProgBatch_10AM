#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[5]; //Array Declaration- 1D Array

    int array[5][3]; //2D Array

    int array[2][2][2]; //3D Array


    int array[5]={4,5,6,7,8}; //Traditional Way of initialization of an Array

    int array[5]={3,5};

    int array[] = {5,6,7,7,8,9,9,9}; //compile time initialization

    int array[2][3]={{2,4,5},
                     {5,6,7}};

    int array[][3]={4,5,6,
                    78,88,90};

    int array[5]= {7,[3]=4}; //designated way of initialization

    int array[2][2][2]= {{{2,3},{4,5},{5,667},{7,8}}}

    return 0;
}
