/*
    Loops:

    1. For Loop
    2. While Loop
    3. Do-While Loop


    For Loop:

    for(initialization; condition; increment/decrement)
    {
            block of code
    }

    While Loop:

    initialization

    while(condition)
    {
        block of Code
        increment/decrement
    }

    Do-While Loop:

    initialization
    do
    {
        block of code
    }while(condition);
*/

