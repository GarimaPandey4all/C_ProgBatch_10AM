#include <stdio.h>
#include <stdlib.h>

int main()
{
    int choice;
    int a, b, c, Largest;

    while(1)
    //for(;;)
    {
    printf("Press 1. for Addition\n");
    printf("Press 2. for Even-Odd\n");
    printf("Press 3. for X-OR\n");
    printf("Press 4. for Left Shift\n");
    printf("Press 5. for Right Shift\n");
    printf("Press 6. for Largest Number\n");
    printf("Press 7. for Exit...\n");

    printf("Enter your Choice:");
    scanf("%d", &choice);

    switch(choice)
    {
    case 1:
        printf("Enter values for a and b:");
        scanf("%d %d", &a, &b);

        printf("Addition of a and b is:%d", a+b);
        break;

    case 2:

        printf("Enter any number:");
        scanf("%d", &a);

        ((a%2)==0) ? printf("Number is Even"):printf("Number is Odd");
        break;

    case 3:
        printf("Enter values for a and b:");
        scanf("%d %d", &a, &b);

        printf("X-OR of a and b is:%d", a^b);
        break;

    case 4:
        printf("Enter any number:");
        scanf("%d", &a);

        printf("Left Shift is:%d", a<<2);
        break;

    case 5:
        printf("Enter any number:");
        scanf("%d", &a);

        printf("Right Shift is:%d", a>>2);
        break;

    case 6:
        printf("Enter three numbers to check which number is Larger:");
        scanf("%d %d %d", &a, &b, &c);

        Largest = (a>b)? ((a>c)?a:c) : ((b>c)?b:c);

        printf("Largest Number is:%d", Largest);
        break;

    case 7:
        exit(0);

    default:
        printf("You have entered the wrong case.");

    }
    }

    return 0;
}
