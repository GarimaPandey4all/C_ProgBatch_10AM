#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, Largest;

    printf("Enter value for a:");
    scanf("%d", &a);

    printf("Enter value for b:");
    scanf("%d", &b);

    printf("Enter value for c:");
    scanf("%d", &c);

    Largest = (a>b) ? ((a>c)?a:c) : ((b>c)?b:c);

    printf("Largest number is: %d", Largest);

    return 0;
}
