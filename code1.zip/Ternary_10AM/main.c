#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, Largest;

    printf("Enter value for a:");
    scanf("%d", &a);

    printf("Enter value for b:");
    scanf("%d", &b);

    Largest = (a>b) ? a:b;

    printf("Largest number is: %d", Largest);

    return 0;
}
