#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    char b;
    float c;
    double d;
    long double e;

    printf("Size of int is: %u\n", sizeof(int));
    printf("Size of char is: %u\n", sizeof(b));
    printf("Size of float is: %u\n", sizeof(c));
    printf("Size of double is: %u\n", sizeof(d));
    printf("Size of long double is: %u\n", sizeof(e));

    return 0;
}
