#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[5], i, sum=0;

    printf("Enter values in an array:");

    for(i=0; i<5; i++)
    scanf("%d", &array[i]);

    for(i=0; i<5; i++)
        sum += array[i];

    printf("Sum is:%d", sum);

    return 0;
}
