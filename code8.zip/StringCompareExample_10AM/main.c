#include <stdio.h> co
#include <stdlib.h>

/*

    string Compare:

    str1 == str2= 0

    str1>str2 = 1, abc>abe

    str1<str2 = -1, abe<abc

*/


int main()
{

    char str1[10];
    char str2[10];

    printf("Enter your String:");
    gets(str1);

    printf("Enter Your String:");
    gets(str2);

    if(strcmp(str1, str2)==0)
    {
        printf("Two Strings are Same.");
    }
    else
    {
        printf("Strings are not Same.");
    }

    return 0;
}
