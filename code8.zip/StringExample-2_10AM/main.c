#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[10];
    char str2[10];

    printf("Enter Your First Name:");
    gets(str1);

    printf("Enter Your Last Name:");
    gets(str2);

    printf("Your Name is: %s %s", str1, str2);

    return 0;
}
