#include <stdio.h>
#include <stdlib.h>

/*
    String Predefined Functions:

    1. String Copy: strcpy()
    2. String Concatenation(joining): strcat()
    3. String Compare: strcmp()
    4. String Lower Case: strlwr()
    5. String Upper Case: strupr()
    6. String Length: strlen()

*/


int main()
{
    char str1[10];

    printf("Enter any String:");
    gets(str1);

    printf("String's Length is: %d", strlen(str1));

    return 0;
}
