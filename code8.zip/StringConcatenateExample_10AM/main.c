#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[10];
    char str2[10];

    printf("Enter any String:");
    gets(str1);

    printf("Enter any String:");
    gets(str2);

    printf("After concatenation the new String is: %s", strcat(str1, str2));

    return 0;
}
