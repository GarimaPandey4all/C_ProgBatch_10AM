#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 0;

    int *pnumber = NULL;

    pnumber = &number;

    number = 10;

    *pnumber += 25;

    printf("Number's value is:%d\n", *pnumber);

    printf("Number's value is:%d\n", &pnumber);

    printf("Number's value is:%d\n", (void*)&pnumber);

    printf("Number's value is:%d", sizeof(pnumber));

    return 0;
}
