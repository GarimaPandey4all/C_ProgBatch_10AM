#include <stdio.h>
#include <stdlib.h>

int main()
{
    long num1 = 0L;
    long num2 = 0L;

    long *pnum = NULL;

    pnum = &num1;
    *pnum = 2L; // num1 = 2;
    ++num2; // num2 = 1;
    num2 += *pnum; // num2 = 1 + 2= 3;

    pnum = &num2;
    ++*pnum; //*pnum= 4;

    printf("Num1 is:%d, Num2 is:%d, *PNUM is:%d, and *PNUM + Num2 is:%d", num1, num2, *pnum,*pnum + num2);

    return 0;
}
