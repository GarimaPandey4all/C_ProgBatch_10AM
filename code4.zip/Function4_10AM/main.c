#include <stdio.h>
#include <stdlib.h>

//Function with arguments and with return value

int add(int, int); //function declaration

int main()
{
    int x, y;
    add(x, y); //function calling
    return 0;
}


//function definition

int add(int a, int b)
{

    printf("Enter values in a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is:%d", a+b);

    return 0;
}
