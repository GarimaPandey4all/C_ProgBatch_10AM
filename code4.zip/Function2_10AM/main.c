#include <stdio.h>
#include <stdlib.h>

//Function with arguments and without return value

void add(int, int); //function declaration

int main()
{
    //add(10, 9);
    int x, y;
    add(x, y);

    return 0;
}


//function definition

void add(int a, int b)
{
    printf("Enter values in a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is:%d", a+b);
}
