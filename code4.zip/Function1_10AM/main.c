#include <stdio.h>
#include <stdlib.h>

//Function without arguments and without return value

void add(); //function declaration

int main()
{
    add(); //function calling
    return 0;
}


//function definition

void add()
{
    int a, b;

    printf("Enter values in a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is:%d", a+b);
}
