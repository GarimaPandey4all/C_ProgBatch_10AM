#include <stdio.h>
#include <stdlib.h>

//Function without arguments and with return value

int add(); //function declaration

int main()
{
//    int result;
//    result=add(); //function calling

    add();
    //printf("Addition is: %d", result);

    return 0;
}


//function definition

int add()
{
    int a, b;

    printf("Enter values in a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is:%d", a+b);

    //return a+b;

    return 0;
}
