#include <stdio.h>
#include <stdlib.h>

int main()
{
    char operator;
    int a,b;

    printf("Enter any Operator:");
    scanf("%c", &operator);

    switch(operator)
    {
    case '+':
        printf("Addition Case\n");
        printf("Enter values for Operands:");
        scanf("%d %d", &a, &b);

        printf("Addition is:%d\n", a+b);
        break;

    case '-':
        printf("Subtraction Case\n");
        printf("Enter values for Operands:");
        scanf("%d %d", &a, &b);

        printf("Subtraction is:%d\n", a-b);
        break;


    case '*':
        printf("Multiplication Case\n");
        printf("Enter values for Operands:");
        scanf("%d %d", &a, &b);

        printf("Multiplication is:%d\n", a*b);
        break;

    case '/':
        printf("Division Case\n");
        printf("Enter values for Operands:");
        scanf("%d %d", &a, &b);

        printf("Division is:%d\n", a/b);
        break;

    case '%':
        printf("Modulus Case\n");
        printf("Enter values for Operands:");
        scanf("%d %d", &a, &b);

        printf("Modulus is:%d\n", a%b);
        break;

    default:
        printf("You have entered the wrong operator");

    }

    return 0;
}
