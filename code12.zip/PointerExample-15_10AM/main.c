#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10], i;

    int *parray = NULL;

    parray = array;

    printf("Enter values in an Array:");
    for(i=0; i<10; i++)
    {
        scanf("%d", parray + i); //pointer arithmetic
    }

    printf("Values in Array are:");
    for(i=0; i<10; i++)
    {
        printf("%d\t", *parray);
        ++parray;
    }

    return 0;
}
