#include <stdio.h>
#include <stdlib.h>

struct Date
{
    int Day;
    int Month;
    int Year;
}date, *pdate;

//struct Date date, *pdate;

int main()
{
    pdate = &date;

    pdate->Day = 1;
    pdate->Month = 3;
    pdate->Year = 2020;

    printf("Day is:%d, Month is:%d, Year is:%d", pdate->Day, pdate->Month, pdate->Year);

    return 0;
}
